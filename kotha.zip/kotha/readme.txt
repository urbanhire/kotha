
=== Kotha ===
Contributors: (shapedtheme, rubel_miah)
Tags: light, white, one-column, two-columns, right-sidebar, fluid-layout, custom-menu, featured-images, post-formats, threaded-comments, translation-ready, theme-options, full-width-template, responsive-layout
Requires at least: 4.0
Tested up to: 4.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


Kotha - Free Responsive WordPress Blog Theme

== Description ==
Kotha is a super clean & elegant Responsive WordPress Blog Theme. It's perfect for your personal, travel, lifestyle, food & recipes, storytelling  Blog. If you want to focus or showcase your content in a timeless manner, Kotha is right choice for you. It follows the latest trendy design with a combination of pure elegance. With Kotha, you can get right to the point, presenting your content in a clean and minimal way. It's very flexible & easy to customize. 3 Custom Widgets, Translation ready, WooCommerce Compatible, Sticky Post, Recent Posts, popular posts and unlimited theme color options, fully live customizer can give you create an high level awesome Blog easily and fast.


== Changelog ==



== Upgrade Notice ==



== Credits ==

* Underscores http://underscores.me (C) 2012-2015 Automattic, Inc., [GPLv2 or later]
* Open Sans(Font) https://www.google.com/fonts/specimen/Open+Sans Apache License, version 2.0
* Bootstrap http://getbootstrap.com (C) 2011-2015 Twitter, Inc. Code released under the MIT license.
* Font Awesome https://fortawesome.github.io/Font-Awesome Font Awesome CSS, LESS, and Sass files are licensed under the MIT License
* FitVids.JS http://fitvidsjs.com FitVids.JS WTFPL license
* SmoothsCroll https://github.com/themicon/smoothscroll Licensed under the terms of the MIT license.
* SlickNav https://github.com/ComputerWolf/SlickNav GPL license.
* Photos https://www.pexels.com Creative Commons Zero (CC0) license.


