<form role="search" method="get" id="searchform" action="<?php echo esc_url(home_url( '/' )); ?>">
    <div>
		<input type="text" placeholder="<?php _e('Search and hit enter...', 'kotha') ?>" name="s" id="s" />
	 </div>
</form>